

class A(object):
    
    def method(self):
        return method
